/*import { LightningElement } from 'lwc';

export default class UtilityComponent extends LightningElement {


}*/

export function formatCustomLabel(label,params) {
    console.log('Params:'+params);
    for(let i=0;i<params.length;i++)
    {
        if(params[i] != 'undefined')
        label=label.replace('{'+i+'}',params[i]);
    }
    return label;
}