import { LightningElement } from 'lwc';

export default class LifecycleHooks extends LightningElement {

    constructor(){
        super();
        console.log('Inside child constructor');
    }

    connectedCallback(){
        console.log('Inside child connectedCallback');
    }

    disconnectedCallback(){
        console.log('Inside child disconnectedCallback');
    }

    renderedCallback(){
        console.log('Inside child renderedCallback');
    }

    /*render(){
        //should return HTML
    }*/

    errorCallback(error,stack){
        console.log('Inside child errorCallback');
    }
}