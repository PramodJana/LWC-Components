import { LightningElement } from 'lwc';
import label1 from '@salesforce/label/c.simpleCustomLabel';
import label2 from '@salesforce/label/c.paramCustomLabel';
import {formatCustomLabel} from 'c/utilityComponent';

import commonCSSFile from '@salesforce/resourceUrl/DemoCSS';
import {loadStyle} from 'lightning/platformResourceLoader';
export default class ShareCodeWhenPossible extends LightningElement {
    simpleCustomLabel=label1;
    paramCustomLabel=label2;

    connectedCallback(){
        this.paramCustomLabel=formatCustomLabel(label2,['test','test2']);

        loadStyle(this,commonCSSFile)
        .then(() => {
            console.log('CSS is now loaded');
        })
        .catch(() => {
            console.log('CSS Loading has failed');
        })
    }
}