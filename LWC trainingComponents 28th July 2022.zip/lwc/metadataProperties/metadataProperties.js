import { LightningElement, api, wire } from 'lwc';

export default class MetadataProperties extends LightningElement {

    callbackVar;
    continueExecution = true;
    @api nameInput;

    renderedCallback() {
        if (this.continueExecution) {
            this.callbackVar = 'Set in RenderedCallback';
            console.log('Name check from renderedCallback:' + this.callbackVar);
            this.continueExecution = false;
        }
    }

    handleButtonClick() {
        this.callbackVar = 'Set by button';
        console.log('Name check from Button:' + this.callbackVar);
    }


}