import { LightningElement } from 'lwc';
import hasViewSetupPermission from '@salesforce/userPermission/ViewSetup';
import hasViewAllPermission from '@salesforce/userPermission/ViewAllData';
import hasModifyAllPermission from '@salesforce/userPermission/ModifyAllData';
import customPermissionCheck from '@salesforce/customPermission/testNewCustomPermission';
export default class UserPermissionComp extends LightningElement {
    setupPermission = hasViewSetupPermission;
    viewAllPermission = hasViewAllPermission;
    modifyallPermission = hasModifyAllPermission;
    testNewCustomPermission = customPermissionCheck;
}