import { LightningElement, track } from 'lwc';

export default class ReactiveProperty extends LightningElement {
    @track reactivePrivateProperty;
    noTrackReactivePrivateProperty;
    @track user = { name: 'John', age: 25 }; //not track

    changeHandler1(event) {
        this.reactivePrivateProperty = event.target.value;
    }

    changeHandler2(event) {
        this.noTrackReactivePrivateProperty = event.target.value;
    }
    setNewDetails(event) {
        console.log('Setting new values');
        this.user.name = this.reactivePrivateProperty;
        this.user.age = this.noTrackReactivePrivateProperty;
    }
}