import { LightningElement, api, wire } from 'lwc';
import { getRecord, updateRecord } from 'lightning/uiRecordApi';
import { ShowToastEvent } from 'lightning/platformShowToastEvent';

const FIELDSLIST = ['Account.Name', 'Account.Phone'];

import ID_FIELD from "@salesforce/schema/Account.Id";
import PHONE_FIELD from "@salesforce/schema/Account.Phone";

export default class CommonUtilities extends LightningElement {
    @api recordId;
    accName;
    accPhone;
    newPhone;

    @wire(getRecord, { recordId: '$recordId', fields: FIELDSLIST })
    wiredData({ data, error }) {
        if (data) {
            this.accName = data.fields.Name.value;
            this.accPhone = data.fields.Phone.value;
            this.newPhone = data.fields.Phone.value;
        }
        else if (error) {
            console.log('Error:' + error);
        }
    }

    handlePhoneChange(event) {
        this.newPhone = event.target.value;
    }

    updateAccRecord() {
        const fields = {};
        fields[ID_FIELD.fieldApiName] = this.recordId;
        fields[PHONE_FIELD.fieldApiName] = this.newPhone;
        const recordInput = {
            fields: fields
          };
          updateRecord(recordInput).then((record) => {
            this.dispatchEvent(
                new ShowToastEvent({
                    title: 'Success',
                    message: 'Account updated',
                    variant: 'success'
                })
            );
          });
    }
}