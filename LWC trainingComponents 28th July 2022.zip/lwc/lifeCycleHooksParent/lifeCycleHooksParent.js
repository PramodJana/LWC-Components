import { LightningElement } from 'lwc';
import originalTemplate from './lifeCycleHooksParent.html';
import newTemplate from './altTemplate.html';
export default class LifeCycleHooksParent extends LightningElement {
    showChild = true;
    toggleRender=true;

    constructor() {
        super();
        console.log('Inside parent constructor');
    }

    connectedCallback() {
        console.log('Inside parent connectedCallback');
    }

    disconnectedCallback() {
        console.log('Inside parent disconnectedCallback');
    }

    renderedCallback() {
        console.log('Inside parent renderedCallback');
    }

    render(){
        console.log('Inside parent render');
        return this.toggleRender?originalTemplate:newTemplate;
    }

    errorCallback(error, stack) {
        console.log('Inside parent errorCallback');
    }

    toggleChild() {
        this.showChild = !this.showChild;
    }
    toggleRenderClick(){
        this.toggleRender=this.toggleRender?false:true;
        console.log('New value of  this.toggleRender: '+ this.toggleRender);
    }
}