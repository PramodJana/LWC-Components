import { LightningElement, wire, track } from 'lwc';
import performSearch from '@salesforce/apex/SearchInAccount.performSearch';

export default class CallApex extends LightningElement {
    searchKey='';
    accRecords;
    cols = [
        {label:'Account Name', fieldName:'Name' , type:'text'} ,
        {label:'Phone', fieldName:'Phone' , type:'Phone'} ,
        {label:'Industry', fieldName:'Industry' , type:'text'}
              
    ]

    /*@wire(performSearch,{searchTerm:'$searchKey'})
    wiredAccounts({data,error})
    {
        console.log('Value of data from wire method:'+data);
        console.log('Value of error from wire method:'+error);
        if(data)
        {
            this.accRecords=data;
        }
        else if(error)
        {
            console.log('Error:'+ error);
        }
    }*/

    handleSearchKey(event){
        this.searchKey = event.target.value;
        this.callAccountSearchImperatively();
    }

    callAccountSearchImperatively(){
        performSearch({searchTerm: this.searchKey})
        .then(result => {
                this.accRecords = result;
        })
        .catch( error=>{
            this.accRecords = null;
        });

    }
    
}